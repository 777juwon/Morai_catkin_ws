#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import math
import tf2_ros
from tf.transformations import quaternion_from_euler
from geometry_msgs.msg import TransformStamped, PoseStamped
from sensor_msgs.msg import Imu
from nav_msgs.msg import Odometry


class GPSIMUParser:
    def __init__(self):
        rospy.init_node('GPS_IMU_parser', anonymous=True)

        # Subscribers
        self.gps_sub = rospy.Subscriber("/gps_pose", PoseStamped, self.pose_callback)
        self.imu_sub = rospy.Subscriber("/imu", Imu, self.imu_callback)

        # Publisher
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=1)

        # State
        self.x = self.y = None
        self.orientation = None
        self.gps_stamp = None
        self.imu_stamp = None
        self.is_gps = False
        self.is_imu = False

        # TF
        self.tf_br = tf2_ros.TransformBroadcaster()

        # Odometry message
        self.odom_msg = Odometry()
        self.odom_msg.header.frame_id = 'map'
        self.odom_msg.child_frame_id = 'base_link'

        rate = rospy.Rate(50)
        while not rospy.is_shutdown():
            if self.is_gps and self.is_imu:
                self.convert_ll_to_utm_and_publish()
            else:
                if not self.is_gps:
                    rospy.logwarn_throttle(5.0, "[GPS_IMU_parser] GPS 메시지 미수신… 연결을 확인하세요")
                if not self.is_imu:
                    rospy.logwarn_throttle(5.0, "[GPS_IMU_parser] IMU 메시지 미수신… 연결을 확인하세요")
            rate.sleep()

    def publish_odom_and_tf(self):
        now = rospy.Time.now()
        self.odom_msg.header.stamp = now

        # 1) /odom publish
        self.odom_pub.publish(self.odom_msg)

        # 2) TF: map -> base_link
        t = TransformStamped()
        t.header.stamp = now
        t.header.frame_id = "map"
        t.child_frame_id  = "base_link"
        t.transform.translation.x = self.odom_msg.pose.pose.position.x
        t.transform.translation.y = self.odom_msg.pose.pose.position.y
        t.transform.translation.z = 0.0
        t.transform.rotation      = self.odom_msg.pose.pose.orientation
        self.tf_br.sendTransform(t)

    def pose_callback(self, msg: PoseStamped):
        # x=easting, y=northing
        # rospy.loginfo("[GPS_IMU_parser] gps_pose x=%.2f y=%.2f", msg.pose.position.x, msg.pose.position.y)
        self.x = msg.pose.position.x
        self.y = msg.pose.position.y
        self.gps_stamp = msg.header.stamp
        self.is_gps = True
        # 콜백에서는 퍼블 금지! (둘 다 준비되면 메인루프에서 퍼블)

    def imu_callback(self, data: Imu):
        # rospy.loginfo("[GPS_IMU_parser] IMU w=%.2f", data.orientation.w)
        self.orientation = data.orientation
        self.imu_stamp = data.header.stamp
        self.is_imu = True
        # 콜백에서는 퍼블 금지!

    def convert_ll_to_utm_and_publish(self):
        # 메시지 채우기
        self.odom_msg.header.stamp = self.gps_stamp or rospy.Time.now()
        self.odom_msg.header.frame_id = 'map'
        self.odom_msg.child_frame_id = 'base_link'

        # position
        self.odom_msg.pose.pose.position.x = float(self.x)
        self.odom_msg.pose.pose.position.y = float(self.y)
        self.odom_msg.pose.pose.position.z = 0.0

        # orientation
        if self.orientation is not None:
            # IMU quaternion -> yaw만 추출해서 roll/pitch 0으로
            qx, qy, qz, qw = (self.orientation.x, self.orientation.y,
                        self.orientation.z, self.orientation.w)
            yaw = math.atan2(2.0*(qw*qz + qx*qy), 1.0 - 2.0*(qy*qy + qz*qz))
            qz_only = quaternion_from_euler(0.0, 0.0, yaw)
            self.odom_msg.pose.pose.orientation.x = qz_only[0]
            self.odom_msg.pose.pose.orientation.y = qz_only[1]
            self.odom_msg.pose.pose.orientation.z = qz_only[2]
            self.odom_msg.pose.pose.orientation.w = qz_only[3]
        else:
            self.odom_msg.pose.pose.orientation.x = 0.0
            self.odom_msg.pose.pose.orientation.y = 0.0
            self.odom_msg.pose.pose.orientation.z = 0.0
            self.odom_msg.pose.pose.orientation.w = 1.0
        # 퍼블은 여기서 한 번만
        self.publish_odom_and_tf()


if __name__ == '__main__':
    try:
        GPSIMUParser()
    except rospy.ROSInterruptException:
        pass
