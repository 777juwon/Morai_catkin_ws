#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import rospy
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Header

# MORAI ROS1 메시지
# 패키지 이름/MSG가 설치되어 있어야 함: rosdep/apt로 morai_msgs 설치
from morai_msgs.msg import GPSMessage

from pyproj import CRS, Transformer


def compute_epsg_from_lonlat(lon: float, lat: float) -> int:
    """
    WGS84 경위도에서 UTM EPSG 코드 계산
    - 북반구: 32600 + zone
    - 남반구: 32700 + zone
    """
    zone = int(math.floor((lon + 180.0) / 6.0) + 1)
    if lat >= 0.0:
        return 32600 + zone
    else:
        return 32700 + zone


class MoraiGpsToPose(object):
    def __init__(self):
        # 파라미터
        self.gps_topic = rospy.get_param("~gps_topic", "/gps")          # MORAI GPSMessage 토픽
        self.pose_topic = rospy.get_param("~pose_topic", "/gps_pose")   # 출력 PoseStamped 토픽
        self.frame_id = rospy.get_param("~frame_id", "map")
        self.use_first_alt_as_ref = rospy.get_param("~use_first_alt_as_ref", True)
        self.alt_ref = rospy.get_param("~alt_ref", 0.0)                 # use_first_alt_as_ref=False일 때 사용

        # 상태 변수
        self._have_alt_ref = not self.use_first_alt_as_ref
        self._east_offset = None
        self._north_offset = None
        self._transformer = None
        self._epsg = None

        # 통신
        self.pub_pose = rospy.Publisher(self.pose_topic, PoseStamped, queue_size=10)
        self.sub_gps = rospy.Subscriber(self.gps_topic, GPSMessage, self.cb_gps, queue_size=50)

        rospy.loginfo("[morai_gps_to_pose] Sub: %s  →  Pub: %s (frame_id=%s)",
                      self.gps_topic, self.pose_topic, self.frame_id)

    def _get_field(self, msg, camel: str, snake: str):
        """필드명이 환경에 따라 camelCase/snake_case가 다를 때 안전하게 접근"""
        if hasattr(msg, camel):
            return getattr(msg, camel)
        elif hasattr(msg, snake):
            return getattr(msg, snake)
        else:
            return None

    def _ensure_transformer(self, lon: float, lat: float):
        if self._transformer is None:
            self._epsg = compute_epsg_from_lonlat(lon, lat)
            self._transformer = Transformer.from_crs(CRS.from_epsg(4326), CRS.from_epsg(self._epsg), always_xy=True)
            rospy.loginfo("[morai_gps_to_pose] Using EPSG:%d (UTM) for lon/lat -> EN conversion", self._epsg)

    def cb_gps(self, msg: GPSMessage):
        # 오프셋(east/north) 읽기 (필드명 양쪽 모두 대응)
        if self._east_offset is None or self._north_offset is None:
            self._east_offset = self._get_field(msg, "eastOffset", "east_offset")
            self._north_offset = self._get_field(msg, "northOffset", "north_offset")
            if self._east_offset is None or self._north_offset is None:
                rospy.logwarn_throttle(5.0, "[morai_gps_to_pose] eastOffset/northOffset가 메시지에 없습니다. 0으로 가정합니다.")
                self._east_offset = self._east_offset or 0.0
                self._north_offset = self._north_offset or 0.0

        # 기준 고도 설정(첫 샘플을 기준으로 쓰는 옵션)
        if not self._have_alt_ref:
            self.alt_ref = msg.altitude
            self._have_alt_ref = True
            rospy.loginfo("[morai_gps_to_pose] alt_ref set to first altitude: %.6f", self.alt_ref)

        # 변환기 준비 (EPSG 계산)
        lon = float(msg.longitude)
        lat = float(msg.latitude)
        alt = float(msg.altitude)
        self._ensure_transformer(lon, lat)

        # 위경도 -> UTM (E,N)
        E, N = self._transformer.transform(lon, lat)

        # 로컬 ENU (x=동, y=북), 고도는 기준값 대비 상대
        x = E - float(self._east_offset)
        y = N - float(self._north_offset)
        z = alt - float(self.alt_ref)

        # PoseStamped publish
        ps = PoseStamped()
        ps.header = Header()
        ps.header.stamp = msg.header.stamp  # GPSMessage의 시간 그대로 사용
        ps.header.frame_id = self.frame_id
        ps.pose.position.x = x
        ps.pose.position.y = y
        ps.pose.position.z = z
        ps.pose.orientation.w = 1.0  # 방향 정보 없음 → 단위 quaternion

        self.pub_pose.publish(ps)


def main():
    rospy.init_node("morai_gps_to_pose", anonymous=False)
    node = MoraiGpsToPose()
    rospy.loginfo("[morai_gps_to_pose] Node started.")
    rospy.spin()


if __name__ == "__main__":
    main()