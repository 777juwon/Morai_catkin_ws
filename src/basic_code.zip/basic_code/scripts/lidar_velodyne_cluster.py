#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import rospy
import math
import numpy as np
from sensor_msgs.msg import PointCloud2, Imu
import sensor_msgs.point_cloud2 as pc2
from geometry_msgs.msg import PoseArray, Pose
from sklearn.cluster import DBSCAN
from std_msgs.msg import Float32MultiArray


class SCANCluster:
    def __init__(self):
        rospy.init_node('velodyne_clustering', anonymous=True)

        # --- Subs / Pubs ---
        rospy.Subscriber("/lidar3D", PointCloud2, self.callback, queue_size=1)
        self.cluster_pub   = rospy.Publisher("/clusters", PoseArray, queue_size=1)
        self.distance_pub  = rospy.Publisher("/cluster_distances", Float32MultiArray, queue_size=1)
        self.filtered_pub  = rospy.Publisher("/lidar_filtered", PointCloud2, queue_size=1)

        p = rospy.get_param

        # 공간 ROI (가로/시야 살짝 축소)
        self.min_r      = float(p("~min_r", 1.65))
        self.max_r      = float(p("~max_r", 45.0))
        self.ahead_m    = float(p("~ahead_m", 80.0))
        self.corridor_y = float(p("~corridor_y", 2.60))   # 3.0 -> 2.7
        self.fov_deg    = float(p("~fov_deg", 40.0))     # 55 -> 45
        self.z_max      = float(p("~z_max",  1.6))
        self.voxel_leaf = float(p("~voxel_leaf", 0.10))

        # 장애물 ROI(가장자리 억제 강화)
        self.obs_shrink_y    = float(p("~obs_shrink_y", 0.82))  # 0.60 -> 0.72 (너무 크게는 금지)
        self.obs_edge_h_min  = float(p("~obs_edge_h_min", 0.40))# 0.34 -> 0.36
        self.edge_guard_y    = float(p("~edge_guard_y", 0.70))  # 0.40 -> 0.50
        self.curb_h_cap      = float(p("~curb_h_cap", 0.40))    # 0.33 -> 0.35

        # 엣지 램프(경계 가까울수록 h 임계↑) + '높은 물체 보존'
        self.edge_ramp_enable = bool(p("~edge_ramp_enable", True))
        self.edge_ramp_gain   = float(p("~edge_ramp_gain", 1.05))  # 0.65 -> 0.80
        self.edge_ramp_h_cap  = float(p("~edge_ramp_h_cap", 0.90))  # 0.60 -> 0.70
        self.edge_preserve_h  = float(p("~edge_preserve_h", 0.62))  # 0.50 -> 0.55 (차/트럭 살림)

        # 적응형 노면 + 2차 피팅 (언덕/볼록면 흡수 ↑)
        self.use_adaptive_ground = bool(p("~use_adaptive_ground", True))
        self.ground_bins   = int(p("~ground_bins", 180))
        self.gnd_near_m    = float(p("~gnd_near_m", 14.0))
        self.use_quad_ground = bool(p("~use_quad_ground", True))
        self.gnd_mid_m       = float(p("~gnd_mid_m", 44.0))  # 38 -> 40
        self.gnd_clear     = float(p("~gnd_clear", 0.17))    # 0.14 -> 0.16
        self.gnd_slope_cap = float(p("~gnd_slope_cap", 0.20))# 0.14 -> 0.18
        self.gnd_curv_cap  = float(p("~gnd_curv_cap", 0.026))# 0.020 -> 0.024
        self.ground_smooth_span = int(p("~ground_smooth_span", 6))  # 3 -> 5

        # 노면 잔존 억제(원거리 바닥 더 흡수)
        self.dynamic_clear_r0 = float(p("~dynamic_clear_r0", 13.5)) # 16 -> 14
        self.far_clear_gain   = float(p("~far_clear_gain", 0.0058))  # 0.0042 -> 0.0050
        self.low_slope_thresh = float(p("~low_slope_thresh", 0.035))
        self.low_slope_extra  = float(p("~low_slope_extra", 0.04))
        self.convex_dr        = float(p("~convex_dr", 0.8))
        self.convex_clear     = float(p("~convex_clear", 0.10))

        # IMU leveling
        self.use_imu_leveling = bool(p("~use_imu_leveling", True))
        self.imu_topic        = p("~imu_topic", "/imu/data")
        self.pitch_deg = 0.0; self.roll_deg  = 0.0
        if self.use_imu_leveling:
            rospy.Subscriber(self.imu_topic, Imu, self.imu_cb, queue_size=10)

        # 내리막/오르막 보정
        self.downhill_pitch_deg = float(p("~downhill_pitch_deg", 2.0))
        self.downhill_h_extra   = float(p("~downhill_h_extra", 0.02))
        self.uphill_pitch_deg    = float(p("~uphill_pitch_deg", 1.8))
        self.uphill_h_extra      = float(p("~uphill_h_extra", 0.03))
        self.hi_slope_thresh     = float(p("~hi_slope_thresh", 0.06))
        self.hi_slope_extra      = float(p("~hi_slope_extra", 0.04))
        self.uphill_convex_extra = float(p("~uphill_convex_extra", 0.03))
        self.dynamic_smooth_gain = float(p("~dynamic_smooth_gain", 0.25))
        self.ground_smooth_max   = int(p("~ground_smooth_max", 3))

        # DBSCAN / Gate (과분할 방지 쪽으로 완화)
        self.db_eps         = float(p("~db_eps", 0.37))  # 0.42 권장
        self.db_min_samples = int(p("~db_min_samples", 7))  # 4 -> 5
        self.dbscan = DBSCAN(eps=self.db_eps, min_samples=self.db_min_samples)

        self.cluster_min_pts = int(p("~cluster_min_pts", 3))
        self.cluster_max_pts = int(p("~cluster_max_pts", 600))
        self.box_w_min = float(p("~box_w_min", 0.15))
        self.box_w_max = float(p("~box_w_max", 3.2))
        self.box_l_min = float(p("~box_l_min", 0.15))
        self.box_l_max = float(p("~box_l_max", 7.5))

        # 커브형(가늘고 긴) 억제(가장자리에만 적용)
        self.curb_shape_gate_enable = bool(p("~curb_shape_gate_enable", True))
        self.curb_edge_guard_y      = float(p("~curb_edge_guard_y", 0.80))  # 0.55 -> 0.65
        self.curb_shape_w_max       = float(p("~curb_shape_w_max", 0.16))   # 0.24 -> 0.20
        self.curb_shape_l_min       = float(p("~curb_shape_l_min", 3.00))   # 1.80 -> 2.20

    # ------------------------------
    def imu_cb(self, msg: Imu):
        q = msg.orientation
        x, y, z, w = q.x, q.y, q.z, q.w
        sinr_cosp = 2.0*(w*x + y*z); cosr_cosp = 1.0 - 2.0*(x*x + y*y)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        sinp = 2.0*(w*y - z*x)
        pitch = math.copysign(math.pi/2, sinp) if abs(sinp) >= 1 else math.asin(sinp)
        self.roll_deg  = math.degrees(roll)
        self.pitch_deg = math.degrees(pitch)

    # ------------------------------
    def callback(self, cloud_msg: PointCloud2):
        hdr = cloud_msg.header
        xy, vis_xyz = self.extract_and_ground_filter(cloud_msg)
        self.publish_filtered_cloud(hdr, vis_xyz)

        if xy is None or len(xy) == 0:
            self.publish_empty(hdr); return

        cluster_msg, centers, min_edge, min_center = self.cluster(xy, header=hdr)
        self.cluster_pub.publish(cluster_msg)

        d = Float32MultiArray(); d.data = [float(min_edge), float(min_center)]
        self.distance_pub.publish(d)

    def publish_empty(self, header):
        msg = PoseArray(); msg.header = header
        self.cluster_pub.publish(msg)
        d = Float32MultiArray(); d.data = [999.0, 999.0]
        self.distance_pub.publish(d)

    def publish_filtered_cloud(self, header, xyz_list):
        try:
            from sensor_msgs.point_cloud2 import create_cloud_xyz32
            self.filtered_pub.publish(create_cloud_xyz32(header, xyz_list))
        except Exception:
            pass

    # ------------------------------
    # Ground modelling + filtering (IMU leveling + edge ramp)
    # ------------------------------
    def extract_and_ground_filter(self, cloud_msg: PointCloud2):
        cand = []
        bins = self.ground_bins

        znear = np.full(bins, np.inf, dtype=np.float32); rnear = np.full(bins, np.inf, dtype=np.float32)
        zmid  = np.full(bins, np.inf, dtype=np.float32); rmid  = np.full(bins, np.inf, dtype=np.float32)
        zfar  = np.full(bins, np.inf, dtype=np.float32); rfar  = np.full(bins, -np.inf, dtype=np.float32)

        near_max = float(self.gnd_near_m); mid_max  = float(self.gnd_mid_m)

        # IMU leveling
        use_lvl = self.use_imu_leveling
        pr = math.radians(self.pitch_deg); rr = math.radians(self.roll_deg)
        if use_lvl:
            cp, sp = math.cos(-pr), math.sin(-pr)  # Ry(-pitch)
            cr, sr = math.cos(-rr), math.sin(-rr)  # Rx(-roll)

        for x0, y0, z0 in pc2.read_points(cloud_msg, field_names=('x', 'y', 'z'), skip_nans=True):
            if use_lvl:
                x1 =  cp*x0 + sp*z0; y1 =  y0; z1 = -sp*x0 + cp*z0
                x  =  x1; y  =  cr*y1 - sr*z1; z  =  sr*y1 + cr*z1
            else:
                x, y, z = x0, y0, z0

            r = math.hypot(x, y)
            if not (self.min_r < r < self.max_r): continue
            if not (0.0 < x <= self.ahead_m): continue
            if abs(y) > self.corridor_y: continue
            if z > self.z_max: continue
            if abs(math.degrees(math.atan2(y, x))) > self.fov_deg: continue

            bi = int(((math.atan2(y, x) + math.pi) / (2.0 * math.pi)) * bins) % bins

            if r <= near_max:
                if z < znear[bi]: znear[bi], rnear[bi] = z, r
            elif r <= mid_max:
                if z < zmid[bi]:  zmid[bi],  rmid[bi]  = z, r
            else:
                if z < zfar[bi]:  zfar[bi],  rfar[bi]  = z, r

            cand.append((x, y, z, bi, r))

        if not cand: return None, []

        # ground model a r^2 + b r + c
        acoef = np.zeros(bins, dtype=np.float32)
        bcoef = np.zeros(bins, dtype=np.float32)
        ccoef = np.zeros(bins, dtype=np.float32)

        if self.use_quad_ground:
            for bi in range(bins):
                pts_r, pts_z = [], []
                if np.isfinite(znear[bi]): pts_r.append(float(rnear[bi])); pts_z.append(float(znear[bi]))
                if np.isfinite(zmid[bi]):  pts_r.append(float(rmid[bi]));  pts_z.append(float(zmid[bi]))
                if np.isfinite(zfar[bi]):  pts_r.append(float(rfar[bi]));  pts_z.append(float(zfar[bi]))
                n = len(pts_r)
                if n >= 3:
                    a, b, c = np.polyfit(np.array(pts_r), np.array(pts_z), 2)
                    a = float(max(-self.gnd_curv_cap, min(self.gnd_curv_cap, a)))
                    acoef[bi], bcoef[bi], ccoef[bi] = a, float(b), float(c)
                elif n == 2:
                    b, c = np.polyfit(np.array(pts_r), np.array(pts_z), 1)
                    acoef[bi], bcoef[bi], ccoef[bi] = 0.0, float(b), float(c)
                elif n == 1:
                    acoef[bi], bcoef[bi], ccoef[bi] = 0.0, 0.0, float(pts_z[0])
                else:
                    acoef[bi], bcoef[bi], ccoef[bi] = 0.0, 0.0, 0.0

        # cross-bin smoothing (+ uphill expand)
        K = int(max(0, self.ground_smooth_span))
        if self.use_imu_leveling and self.pitch_deg > self.uphill_pitch_deg:
            addK = int(self.dynamic_smooth_gain * (self.pitch_deg - self.uphill_pitch_deg))
            K = min(self.ground_smooth_max, K + max(0, addK))

        if K > 0:
            W = 2*K + 1
            def smooth(arr):
                out = np.zeros_like(arr, dtype=np.float32)
                for o in range(-K, K+1): out += np.roll(arr, o)
                return (out / float(W)).astype(np.float32)
            acoef = smooth(acoef); bcoef = smooth(bcoef); ccoef = smooth(ccoef)

        def zg_eval(bi, r):    return float(acoef[bi]*r*r + bcoef[bi]*r + ccoef[bi])
        def slope_eval(bi, r): return float(2.0*acoef[bi]*r + bcoef[bi])

        raw_xy = []; vis_xyz = []
        edge_start     = self.corridor_y - self.edge_guard_y
        obs_edge_start = self.corridor_y - self.obs_shrink_y

        # 내리막/오르막 보정 항
        downhill_extra = 0.0
        if self.use_imu_leveling and self.pitch_deg < -self.downhill_pitch_deg:
            downhill_extra = self.downhill_h_extra
        uphill_extra = 0.0; convex_bonus = 0.0
        if self.use_imu_leveling and self.pitch_deg > self.uphill_pitch_deg:
            pitch_over = self.pitch_deg - self.uphill_pitch_deg
            uphill_extra = self.uphill_h_extra * (1.0 + 0.2 * min(5.0, pitch_over))
            convex_bonus = self.uphill_convex_extra

        for x, y, z, bi, r in cand:
            keep = True
            if self.use_adaptive_ground:
                zg = zg_eval(bi, r)
                h  = z - zg

                # 기본 + 거리 가중 + 내리막/오르막 보정
                h_th = self.gnd_clear + downhill_extra + uphill_extra
                if r > self.dynamic_clear_r0:
                    h_th += self.far_clear_gain * (r - self.dynamic_clear_r0)

                s = abs(slope_eval(bi, r))
                if s < self.low_slope_thresh: h_th += self.low_slope_extra
                if s > self.hi_slope_thresh:  h_th += self.hi_slope_extra

                # convex test
                if self.convex_dr > 1e-3:
                    rm = max(self.min_r + 0.1, r - self.convex_dr)
                    rp = min(self.max_r - 0.1, r + self.convex_dr)
                    h_cv = z - 0.5*(zg_eval(bi, rm) + zg_eval(bi, rp))
                else:
                    h_cv = h
                if (h < h_th) or (h_cv < self.convex_clear + convex_bonus):
                    keep = False

                # 엣지 램프(경계에 가까울수록 더 높은 h 요구) + 높은 물체 보존
                if keep and self.edge_ramp_enable and abs(y) >= edge_start:
                    edge_pen = abs(y) - edge_start  # 0~edge_guard_y
                    h_ramped = self.curb_h_cap + self.edge_ramp_gain * edge_pen
                    if self.edge_ramp_h_cap > 0.0:
                        h_ramped = min(h_ramped, self.edge_ramp_h_cap)
                    if (h < h_ramped) and (h < self.edge_preserve_h):
                        keep = False

                # 보조: 가장자리 억제는 '높은 물체는 통과'
                if keep and abs(y) >= edge_start and h < min(self.curb_h_cap, self.edge_preserve_h):
                    keep = False
                if keep and abs(y) >= obs_edge_start and h < min(self.obs_edge_h_min, self.edge_preserve_h):
                    keep = False

            if keep:
                raw_xy.append((x, y))
                vis_xyz.append((x, y, z))

        if not raw_xy: return None, vis_xyz

        # voxel (xy)
        leaf = float(self.voxel_leaf); leaf = 0.10 if leaf <= 0 else leaf
        inv = 1.0 / leaf
        vox = {}
        for x, y in raw_xy:
            kx = math.floor(x * inv); ky = math.floor(y * inv)
            sx, sy, c = vox.get((kx, ky), (0.0, 0.0, 0))
            vox[(kx, ky)] = (sx + x, sy + y, c + 1)

        xy = np.array([(sx / c, sy / c) for (sx, sy, c) in vox.values()], dtype=float)
        return xy, vis_xyz

    # ------------------------------
    # DBSCAN + 게이트(박스-겹침)
    # ------------------------------
    def cluster(self, xy: np.ndarray, header):
        pa = PoseArray(); pa.header = header
        centers = []; min_edge = float('inf'); min_center = float('inf')

        try:
            labels = self.dbscan.fit_predict(xy)
        except ValueError:
            return pa, centers, 999.0, 999.0

        uniq = [k for k in np.unique(labels) if k != -1]
        for k in uniq:
            pts = xy[labels == k]; n = pts.shape[0]
            if n < self.cluster_min_pts or n > self.cluster_max_pts: continue

            xs = pts[:, 0]; ys = pts[:, 1]
            w = float(ys.max() - ys.min()); l = float(xs.max() - xs.min())
            cx = float(xs.mean());         cy = float(ys.mean())

            if not (self.box_w_min <= w <= self.box_w_max and self.box_l_min <= l <= self.box_l_max):
                continue
            if not (0.0 < cx <= self.ahead_m):
                continue

            # 가장자리에 붙어도 박스가 차로 안쪽 띠와 '겹치면' 통과
            inner = self.corridor_y - self.obs_shrink_y
            if abs(cy) - 0.5*w > inner:
                continue

            if self.curb_shape_gate_enable:
                edge_start = (self.corridor_y - self.obs_shrink_y) - self.curb_edge_guard_y
                if abs(cy) >= edge_start and (w <= self.curb_shape_w_max) and (l >= self.curb_shape_l_min):
                    continue

            p = Pose(); p.position.x = cx; p.position.y = cy; p.position.z = 0.0
            pa.poses.append(p); centers.append((cx, cy))

            d_edge_k = float(np.min(np.hypot(xs, ys)));  d_center_k = math.hypot(cx, cy)
            if d_edge_k   < min_edge:   min_edge   = d_edge_k
            if d_center_k < min_center: min_center = d_center_k

        if not centers:
            return pa, centers, 999.0, 999.0
        return pa, centers, (min_edge if np.isfinite(min_edge) else 999.0), (min_center if np.isfinite(min_center) else 999.0)


if __name__ == '__main__':
    SCANCluster()
    rospy.spin()
