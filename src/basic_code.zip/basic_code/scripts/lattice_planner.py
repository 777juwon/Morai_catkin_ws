#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy, math, numpy as np
from math import cos, sin, atan2
from geometry_msgs.msg import PoseArray, PoseStamped
from nav_msgs.msg import Path, Odometry
from morai_msgs.msg import EgoVehicleStatus
from std_msgs.msg import Float32MultiArray, Bool
import tf2_ros, tf2_geometry_msgs

class latticePlanner:
    def __init__(self):
        rospy.init_node('lattice_planner', anonymous=True)

        # Subs
        rospy.Subscriber("/global_path", Path, self.path_cb)
        rospy.Subscriber("/odom", Odometry, self.odom_cb)
        rospy.Subscriber("/Competition_topic", EgoVehicleStatus, self.status_cb)
        rospy.Subscriber("/right_path", Path, self.right_cb)
        rospy.Subscriber("/clusters", PoseArray, self.clusters_cb, queue_size=1)
        rospy.Subscriber("/cluster_distances", Float32MultiArray, self.dist_cb, queue_size=1)

        # Pubs
        self.pub_path  = rospy.Publisher("/lattice_path", Path, queue_size=1)
        self.pub_speed = rospy.Publisher("/speed_control", Bool, queue_size=1)

        # States
        self.is_path = self.is_odom = self.is_status = False
        self.local_path = None; self.right_path = None
        self.vx = self.vy = None
        self.v_mps = 0.0; self.v_kph = 0.0
        self.clusters_map = None; self.min_dist_m = None

        # TF
        self.tfbuf = tf2_ros.Buffer(); self.tfl = tf2_ros.TransformListener(self.tfbuf)

        # Road / corridor
        g = rospy.get_param
        self.road_half_w      = g("~road_half_width", 2.6)
        self.corridor_ahead_m = g("~corridor_ahead_m", 45.0)
        self.path_inflation_m = g("~path_inflation_m", 0.4)

        # Avoid hysteresis
        self.avoid_on_frames  = g("~avoid_on_frames", 3)
        self.avoid_off_frames = g("~avoid_off_frames", 8)
        self._vote = 0; self.avoid_active = False

        # Free-space bands
        self.band_dx          = g("~band_dx", 0.5)
        self.car_width        = g("~car_width", 1.90)
        self.lat_margin       = g("~lat_margin", 0.45)
        self.required_clear   = 0.5*self.car_width + self.lat_margin
        self.side_guard       = g("~side_guard", 0.8)

        # Trigger
        self.trigger_min_clusters = g("~trigger_min_clusters", 1)

        # Candidates / scoring
        self.clearance_stride = g("~clearance_stride", 2)
        self.clearance_soft_w = g("~clearance_soft_weight", 10.0)

        # Commit logic
        self.avoid_commit_m   = g("~avoid_commit_m", 22.0)
        self._hold_until_s    = None
        self._sticky_side     = 0  # -1 L, +1 R

        # Candidate generation (Bezier + guards)
        self.edge_margin      = g("~edge_margin", 0.45)
        self.avoid_x_scale    = g("~avoid_x_end_scale", 0.9)
        self.bez_alpha        = g("~bezier_alpha", 0.18)
        self.bez_beta         = g("~bezier_beta", 0.18)
        self.bez_push         = g("~bezier_push", 0.8)
        self.bez_relax        = g("~bezier_relax", 0.35)
        self.min_x_end_m      = g("~min_x_end_m", 20.0)
        self.min_points       = g("~min_points", 40)

        # REJOIN
        self.rejoin_clear_m      = g("~rejoin_clear_m", 14.0)
        self.rejoin_clear_frames = g("~rejoin_clear_frames", 4)
        self.rejoin_x_m          = g("~rejoin_x_m", 14.0)
        self.rejoin_lat_eps      = g("~rejoin_lat_eps", 0.35)
        self._rejoin_cnt  = 0
        self._rejoin_mode = False

        # Safety guards
        self.dynamic_lat_k          = g("~dynamic_lat_k", 0.03)
        self.band_dilate_m          = g("~band_dilate_m", 0.20)
        self.min_free_prefix_m      = g("~min_free_prefix_m", 14.0)
        self.clearance_window_m     = g("~clearance_window_m", 22.0)
        self.clearance_percentile_q = g("~clearance_percentile_q", 20.0)

        self.main_hz = 15
        self._last_idx = None
        self.idx_step_cap = g("~idx_step_cap", 2)

        # NEW: 기본 좌측 선호(장애물 없을 때)
        self.default_avoid_side = g("~default_avoid_side", -1)  # -1: 좌, +1: 우

        rospy.loginfo("lattice_planner: start")
        self.spin()

    # --------- callbacks ---------
    def path_cb(self, msg):   self.is_path=True;  self.local_path=msg
    def right_cb(self, msg):  self.right_path=msg
    def odom_cb(self, msg):   self.is_odom=True;  self.vx=msg.pose.pose.position.x; self.vy=msg.pose.pose.position.y
    def status_cb(self, msg): self.is_status=True; self.v_mps=max(0.0,float(msg.velocity.x)); self.v_kph=self.v_mps*3.6
    def dist_cb(self, msg):   self.min_dist_m = float(min(msg.data)) if msg.data else None

    def clusters_cb(self, pa: PoseArray):
        try:
            T = self.tfbuf.lookup_transform('map', pa.header.frame_id, pa.header.stamp, rospy.Duration(0.2))
        except Exception:
            try:
                T = self.tfbuf.lookup_transform('map', pa.header.frame_id, rospy.Time(0), rospy.Duration(0.2))
            except Exception as e:
                rospy.logwarn_throttle(1.0, f"[lattice] cluster tf fail: {e}")
                self.clusters_map=None; return
        pa_map = PoseArray(); pa_map.header.frame_id='map'; pa_map.header.stamp=pa.header.stamp
        pa_map.poses=[tf2_geometry_msgs.do_transform_pose(PoseStamped(header=pa.header,pose=p),T).pose for p in pa.poses]
        self.clusters_map=pa_map

    # --------- main loop ----------
    def spin(self):
        rate=rospy.Rate(self.main_hz)
        while not rospy.is_shutdown():
            if not (self.is_path and self.is_odom and self.is_status):
                rate.sleep(); continue

            d_on = 6.0 + 0.6*self.v_mps + (self.v_mps*self.v_mps)/(2.0*3.0)

            n_on, min_longi = self._count_on_path(self.local_path, infl=self.path_inflation_m)
            is_close = (self.min_dist_m is not None) and (self.min_dist_m < d_on)
            on_path  = (n_on >= self.trigger_min_clusters)

            want = is_close or on_path
            self._vote = min(self._vote+1, self.avoid_on_frames) if want else max(self._vote-1, -self.avoid_off_frames)

            s_now = self._cur_s(self.local_path, self.vx, self.vy)

            if (not self.avoid_active) and (self._vote >= self.avoid_on_frames):
                self.avoid_active=True; self._hold_until_s=None; self._sticky_side=0

            if self.avoid_active:
                if self._hold_until_s is None and s_now is not None:
                    self._hold_until_s = s_now + self.avoid_commit_m

                clear_front = (n_on == 0) and (self.min_dist_m is None or self.min_dist_m > self.rejoin_clear_m)
                self._rejoin_cnt = self._rejoin_cnt + 1 if clear_front else 0

                if (self._hold_until_s is not None) and (s_now is not None) and (s_now >= self._hold_until_s):
                    self._rejoin_mode = (self._rejoin_cnt >= self.rejoin_clear_frames)
                else:
                    self._rejoin_mode = False

                if (self._hold_until_s is not None) and (s_now is not None) and (s_now >= self._hold_until_s):
                    if self._vote <= -self.avoid_off_frames:
                        clear_front = (n_on == 0) and (self.min_dist_m is None or self.min_dist_m > self.rejoin_clear_m)
                        lat_err = self._lat_err_to_global()
                        if clear_front and (lat_err is not None) and (lat_err < self.rejoin_lat_eps):
                            self.avoid_active=False
                            self._sticky_side=0
                            self._rejoin_mode=False
                            self._last_idx=None

            rospy.loginfo_throttle(0.5,
                "[avoid] v=%.1f d_on=%.1f min_d=%s on_path(n=%d,longi=%.1f) vote=%d active=%s rejoin=%s",
                self.v_mps, d_on, str(self.min_dist_m), n_on, min_longi, self._vote, self.avoid_active, self._rejoin_mode)

            self._publish(self.avoid_active)
            rate.sleep()

    # --------- helpers ----------
    def _lat_err_to_global(self):
        path=self.local_path
        if path is None or len(path.poses)<2 or self.vx is None: return None
        xs=[p.pose.position.x for p in path.poses]; ys=[p.pose.position.y for p in path.poses]
        j=min(range(len(xs)), key=lambda i:(xs[i]-self.vx)**2+(ys[i]-self.vy)**2)
        if j>=len(xs)-1: j=max(0, j-1)
        th=math.atan2(ys[j+1]-ys[j], xs[j+1]-xs[j])
        dx,dy=self.vx-xs[j], self.vy-ys[j]
        lat = -math.sin(th)*dx + math.cos(th)*dy
        return abs(float(lat))

    def _req_clear(self):
        return 0.5*self.car_width + self.lat_margin + self.dynamic_lat_k * float(self.v_mps)

    def _cur_s(self, path:Path, x, y):
        if path is None or len(path.poses)<2: return None
        xs=np.array([p.pose.position.x for p in path.poses]); ys=np.array([p.pose.position.y for p in path.poses])
        j=int(np.argmin((xs-x)**2+(ys-y)**2))
        ds=np.hypot(np.diff(xs),np.diff(ys)); s=np.concatenate([[0.0],np.cumsum(ds)])
        return float(s[j])

    def _count_on_path(self, path:Path, infl:float=0.4):
        cm=self.clusters_map
        if (cm is None) or (path is None) or (len(path.poses)<2): return 0, 999.0
        xs=[p.pose.position.x for p in path.poses]; ys=[p.pose.position.y for p in path.poses]
        vx,vy=self.vx,self.vy
        j=min(range(len(xs)), key=lambda i:(xs[i]-vx)**2+(ys[i]-vy)**2)
        j2=min(len(xs)-1, j+250)
        lane_w=self.road_half_w + infl
        ahead=min(self.corridor_ahead_m, 6.0+0.6*self.v_mps+(self.v_mps**2)/(2*3.0)+8.0)

        cnt=0; min_longi=999.0
        for o in cm.poses:
            ox,oy=o.position.x,o.position.y
            k=min(range(j,j2), key=lambda i:(xs[i]-ox)**2+(ys[i]-oy)**2)
            if k>=len(xs)-1: continue
            yaw=math.atan2(ys[k+1]-ys[k], xs[k+1]-xs[k])
            dx,dy=ox-xs[k],oy-ys[k]
            longi = math.cos(yaw)*dx + math.sin(yaw)*dy
            lat   =-math.sin(yaw)*dx + math.cos(yaw)*dy
            if 0.0<=longi<=ahead and abs(lat)<=lane_w:
                cnt+=1; min_longi=min(min_longi,longi)
        return cnt, min_longi

    def _build_bands(self, path:Path):
        cm=self.clusters_map
        if (cm is None) or (path is None) or (len(path.poses)<2): return []

        xs=np.array([p.pose.position.x for p in path.poses]); ys=np.array([p.pose.position.y for p in path.poses])
        vx,vy=self.vx,self.vy
        j0=int(np.argmin((xs-vx)**2+(ys-vy)**2))
        yaw=[math.atan2(ys[i+1]-ys[i], xs[i+1]-xs[i]) for i in range(len(xs)-1)]; yaw.append(yaw[-1])

        N=int(self.corridor_ahead_m/self.band_dx)+1
        bands=[[] for _ in range(N)]

        for o in cm.poses:
            ox,oy=o.position.x,o.position.y
            k=min(range(j0, min(len(xs)-1,j0+250)), key=lambda i:(xs[i]-ox)**2+(ys[i]-oy)**2)
            th=yaw[k]
            dx,dy=ox-xs[k],oy-ys[k]
            longi= math.cos(th)*dx + math.sin(th)*dy
            lat  =-math.sin(th)*dx + math.cos(th)*dy
            if not (0.0<=longi<=self.corridor_ahead_m): continue
            if abs(lat) > (self.road_half_w + self.side_guard): continue
            b=int(longi//self.band_dx)
            rad=self._req_clear()
            bands[b].append((lat-rad, lat+rad))

        # merge + dilate
        for i in range(N):
            iv=bands[i]
            if not iv: continue
            iv=sorted(iv, key=lambda x:x[0])
            m=[iv[0]]
            for a,c in iv[1:]:
                if a<=m[-1][1]: m[-1]=(m[-1][0], max(m[-1][1], c))
                else: m.append((a,c))
            if self.band_dilate_m > 0.0:
                d = float(self.band_dilate_m)
                lim = self.road_half_w + self.side_guard + 1.0
                m = [ (max(-lim, a - d), min(lim, c + d)) for (a,c) in m ]
            bands[i]=m
        return bands

    def _path_is_free(self, cand:Path, bands) -> bool:
        if (cand is None) or (not cand.poses) or (not bands) or (self.local_path is None): return True
        xs=np.array([p.pose.position.x for p in self.local_path.poses])
        ys=np.array([p.pose.position.y for p in self.local_path.poses])
        yaw=[math.atan2(ys[i+1]-ys[i], xs[i+1]-xs[i]) for i in range(len(xs)-1)]; yaw.append(yaw[-1])
        j0=int(np.argmin((xs-self.vx)**2+(ys-self.vy)**2))

        for ps in cand.poses[::max(1,self.clearance_stride)]:
            k=min(range(j0, min(len(xs)-1, j0+250)), key=lambda i:(xs[i]-ps.pose.position.x)**2+(ys[i]-ps.pose.position.y)**2)
            th=yaw[k]
            dx,dy=ps.pose.position.x-xs[k], ps.pose.position.y-ys[k]
            longi= math.cos(th)*dx + math.sin(th)*dy
            lat  =-math.sin(th)*dx + math.cos(th)*dy
            if longi<0.0 or longi>self.corridor_ahead_m: continue
            b=int(longi//self.band_dx)
            if b>=len(bands): break
            for a,c in bands[b]:
                if (a-0.05)<=lat<=(c+0.05): return False
        return True

    def _first_collision_m(self, cand:Path, bands) -> float:
        if cand is None or not cand.poses or not bands or self.local_path is None:
            return float('inf')
        xs=np.array([p.pose.position.x for p in self.local_path.poses])
        ys=np.array([p.pose.position.y for p in self.local_path.poses])
        yaw=[math.atan2(ys[i+1]-ys[i], xs[i+1]-xs[i]) for i in range(len(xs)-1)]; yaw.append(yaw[-1])
        j0=int(np.argmin((xs-self.vx)**2+(ys-self.vy)**2))
        step=max(1, self.clearance_stride)
        for ps in cand.poses[::step]:
            k=min(range(j0, min(len(xs)-1, j0+250)), key=lambda i:(xs[i]-ps.pose.position.x)**2+(ys[i]-ps.pose.position.y)**2)
            th=yaw[k]
            dx,dy=ps.pose.position.x-xs[k], ps.pose.position.y-ys[k]
            longi= math.cos(th)*dx + math.sin(th)*dy
            lat  =-math.sin(th)*dx + math.cos(th)*dy
            if longi<0.0: continue
            b=int(longi//self.band_dx)
            if 0<=b<len(bands):
                for a,c in bands[b]:
                    if (a-0.05)<=lat<=(c+0.05):
                        return float(longi)
            if longi>self.corridor_ahead_m: break
        return float('inf')

    # NEW: 전방 장애물 좌/우 힌트 (우측 +1, 좌측 -1, 없으면 0)
    def _nearest_obstacle_side_ahead(self, ahead_m: float = 30.0) -> int:
        cm = self.clusters_map
        path = self.local_path
        if cm is None or path is None or len(path.poses) < 2 or self.vx is None:
            return 0
        xs = np.array([p.pose.position.x for p in path.poses])
        ys = np.array([p.pose.position.y for p in path.poses])
        j0 = int(np.argmin((xs - self.vx) ** 2 + (ys - self.vy) ** 2))
        if j0 >= len(xs) - 1: j0 = max(0, len(xs) - 2)
        yaw = [math.atan2(ys[i+1]-ys[i], xs[i+1]-xs[i]) for i in range(len(xs)-1)]; yaw.append(yaw[-1])

        best_longi = float('inf'); best_lat = 0.0
        lane_guard = self.road_half_w + self.side_guard
        kmax = min(len(xs) - 1, j0 + 250)

        for o in cm.poses:
            ox, oy = o.position.x, o.position.y
            k = min(range(j0, kmax), key=lambda i: (xs[i]-ox)**2 + (ys[i]-oy)**2)
            th = yaw[k]
            dx, dy = ox - xs[k], oy - ys[k]
            longi = math.cos(th)*dx + math.sin(th)*dy
            lat   = -math.sin(th)*dx + math.cos(th)*dy
            if 0.0 <= longi <= ahead_m and abs(lat) <= lane_guard:
                if longi < best_longi:
                    best_longi = longi; best_lat = lat
        if best_longi is float('inf'): return 0
        return 1 if best_lat > 0.0 else -1

    # --------- publish ----------
    def _publish(self, avoid:bool):
        if avoid:
            cands=self._make_candidates(self.local_path)
            if not cands or max(len(p.poses) for p in cands) < self.min_points:
                if self.local_path: self.pub_path.publish(self.local_path)
                self.pub_speed.publish(Bool(True))
                rospy.logwarn("[lattice] poor candidates -> fallback to local_path")
                return

            bands=self._build_bands(self.local_path)
            free=[i for i,p in enumerate(cands) if self._path_is_free(p,bands)]
            center=len(cands)//2

            safe = [i for i in free if self._first_collision_m(cands[i], bands) >= self.min_free_prefix_m]
            pool = safe if safe else free

            # NEW: 앞쪽 장애물이 '오른쪽'이면 왼쪽 후보만 남겨라
            side_hint = self._nearest_obstacle_side_ahead(ahead_m=min(self.corridor_ahead_m, 30.0))
            if side_hint > 0:  # obstacle on right -> go left only
                pool = [i for i in pool if i < center] or pool
            elif side_hint == 0 and self.default_avoid_side < 0:
                prefer = [i for i in pool if i < center]
                pool = prefer or pool

            # ------------------ REJOIN/선택 ------------------
            if self._rejoin_mode and pool:
                idx = min(pool, key=lambda i: abs(i-center))
            else:
                if pool:
                    if self._sticky_side==0:
                        left_w  = sum(sum(abs(a) for a,_ in row if a<0) for row in bands)
                        right_w = sum(sum(c      for a,c in row if c>0) for row in bands)
                        self._sticky_side = -1 if left_w < right_w else +1
                    side = [i for i in pool if (i<center if self._sticky_side<0 else i>center)]
                    choose_from = side or pool
                    # 안전 여유 퍼센타일 최대
                    idx = max(choose_from,
                              key=lambda i: self._clearance_percentile(
                                  cands[i], self.clearance_window_m, self.clearance_percentile_q))
                else:
                    # 빈 풀 방어적 백업
                    backup = free if free else list(range(len(cands)))
                    if side_hint > 0:
                        backup_pref = [i for i in backup if i < center] or backup
                    elif side_hint < 0:
                        backup_pref = [i for i in backup if i > center] or backup
                    elif self.default_avoid_side < 0:
                        backup_pref = [i for i in backup if i < center] or backup
                    else:
                        backup_pref = backup
                    if backup_pref:
                        idx = max(backup_pref,
                                  key=lambda i: self._clearance_percentile(
                                      cands[i], self.clearance_window_m, self.clearance_percentile_q))
                    else:
                        idx = center  # 최후의 방어

            # 관성 제한
            if self._last_idx is not None and avoid and not self._rejoin_mode:
                cap = int(max(1, self.idx_step_cap))
                if idx > self._last_idx + cap:   idx = self._last_idx + cap
                elif idx < self._last_idx - cap: idx = self._last_idx - cap
            self._last_idx = idx

            idx=max(0, min(idx, len(cands)-1))
            self.pub_path.publish(cands[idx])
            self.pub_speed.publish(Bool(True))
            rospy.loginfo("[lattice] avoid ON, choose #%d (rejoin=%s, side_hint=%d, safe_pool=%d/%d)",
                          idx, self._rejoin_mode, side_hint, len(safe), len(free))
        else:
            if self.local_path: self.pub_path.publish(self.local_path)
            self.pub_speed.publish(Bool(False))
            self._last_idx = None
            rospy.loginfo("[lattice] avoid OFF -> follow global")

    # --------- scoring fallback ----------
    def _choose_by_clearance(self, cands):
        need=self._req_clear()
        weights=[]
        for p in cands:
            cl=self._min_clear(p, self.clusters_map, self.clearance_stride)
            w = 1_000_000 if cl<need else self.clearance_soft_w/max(0.1, cl)
            weights.append(w)
        return int(np.argmin(weights))

    def _min_clear(self, path:Path, cm:PoseArray, stride:int):
        if (path is None) or (not path.poses) or (cm is None) or (not cm.poses): return float('inf')
        pts=path.poses[::max(1,stride)]
        m=float('inf')
        for ps in pts:
            px,py=ps.pose.position.x, ps.pose.position.y
            for o in cm.poses:
                d=math.hypot(px-o.position.x, py-o.position.y)
                if d<m: m=d
        return m

    # --------- candidates (Bezier) ----------
    def _make_candidates(self, ref:Path):
        out=[]
        if ref is None or self.vx is None: return out
        xs=[p.pose.position.x for p in ref.poses]; ys=[p.pose.position.y for p in ref.poses]
        if len(xs)<3: return out

        j=int(np.argmin((np.array(xs)-self.vx)**2 + (np.array(ys)-self.vy)**2))
        v_kph=self.v_kph; look=int(max(20, v_kph*0.4))
        s=max(0, j-1); e=min(len(xs)-1, s+look*2)

        sx,sy=xs[s],ys[s]; nx,ny=xs[s+1],ys[s+1]; ex,ey=xs[e],ys[e]
        th=atan2(ny-sy, nx-sx)
        T =np.array([[cos(th),-sin(th),sx],[sin(th),cos(th),sy],[0,0,1]])
        Ti=np.array([[ T[0,0], T[1,0], -(T[0,0]*sx + T[1,0]*sy)],
                     [ T[0,1], T[1,1], -(T[0,1]*sx + T[1,1]*sy)],[0,0,1]])

        le = Ti.dot(np.array([[ex],[ey],[1]])); xe=float(le[0]); y_end=float(le[1])
        le0=Ti.dot(np.array([[self.vx],[self.vy],[1]])); y0=float(le0[1])

        if xe<=1.0:
            e=min(len(xs)-1, s+look*3); ex,ey=xs[e],ys[e]; le=Ti.dot(np.array([[ex],[ey],[1]])); xe=float(le[0])
            if xe<=1.0: return out

        if self.avoid_active: xe*=float(np.clip(self.avoid_x_scale, 0.8, 1.0))
        xe=min(max(xe, max(self.min_x_end_m, 4.0+2.0*self.v_mps)), 80.0)

        if self._rejoin_mode:
            xe = min(xe, max(8.0, float(self.rejoin_x_m)))

        W=self.road_half_w - self.edge_margin
        offsets=[-W, -0.75*W, -0.5*W, -0.35*W, -0.2*W, -0.1*W, 0.0, 0.1*W, 0.2*W, 0.35*W, 0.5*W, 0.75*W, W]

        N=max(self.min_points, int(xe/0.5)+1)
        for ofs in offsets:
            P0=np.array([0.0, y0], float)
            P3=np.array([xe, y_end + ofs], float)
            P1=np.array([xe*self.bez_alpha,          y0 + ofs*self.bez_push], float)
            P2=np.array([xe*(1.0-self.bez_beta), P3[1]-ofs*self.bez_relax], float)

            lp=Path(); lp.header.frame_id='map'
            for i in range(N):
                t=i/float(N-1)
                B=((1-t)**3)*P0 + 3*((1-t)**2)*t*P1 + 3*(1-t)*(t**2)*P2 + (t**3)*P3
                gp=T.dot(np.array([[B[0]],[B[1]],[1.0]]))
                ps=PoseStamped(); ps.pose.position.x=float(gp[0,0]); ps.pose.position.y=float(gp[1,0])
                ps.pose.position.z=0.0; ps.pose.orientation.w=1.0
                lp.poses.append(ps)
            out.append(lp)
        return out

if __name__ == '__main__':
    try:
        latticePlanner()
    except rospy.ROSInterruptException:
        pass
