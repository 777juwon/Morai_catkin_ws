#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import numpy as np
import rospy
from math import cos, sin, atan2, sqrt, pi

# [ADD] lattice 입력
from nav_msgs.msg import Path
from std_msgs.msg import Bool
from std_msgs.msg import String

from custom_msgs.msg import status, waypointarray
from morai_msgs.msg import CtrlCmd, EventInfo
from morai_msgs.srv import MoraiEventCmdSrv, MoraiEventCmdSrvRequest



def wrap_angle(a: float) -> float:
    return (a + pi) % (2 * pi) - pi


class StanleyController:
    # ───────────────────────────────────────────────────────────────────
    def __init__(self):
        rospy.init_node("stanley_node", anonymous=True)

        # 1) 경로 웨이포인트: 구독은 하지만, 최초 1회만 채택 ─────────────
        self.path_received = False
        self.path = None
        self.xs = None
        self.ys = None
        self.vs = None
        self.s = None
        self.s_end = None
        self.last_xy = None
        self.N = 0

        rospy.Subscriber("/global_waypoints", waypointarray, self._waypoints_callback, queue_size=1)
        rospy.loginfo(">> /global_waypoints 구독 시작 (최초 1개만 채택)")

        # 1-추가) /traffic, /stop_line 구독 (값 저장만)
        self.traffic_state = None   # type: str|None
        self.stop_line_state = None # type: bool|None
        rospy.Subscriber("/traffic", String, self.traffic_callback, queue_size=1)
        rospy.Subscriber("/stop_line", Bool, self.stop_line_callback, queue_size=1)

        # 2) 전방점 순차 탐색 설정 ─────────────────────────────────
        self.j_idx = 0
        self.search_ahead = rospy.get_param("~search_ahead", 45)

        # 3) 퍼블리셔 및 /status 구독 ──────────────────────────────
        self.pub = rospy.Publisher("/ctrl_cmd_0", CtrlCmd, queue_size=1)
        self.cmd = CtrlCmd()
        self.cmd.longlCmdType = 1  # accel/brake 모드

        self.status_received = False
        self.cur_pos = None
        self.yaw = 0.0
        self.kph = 0.0
        rospy.Subscriber("/status", status, self.status_callback, queue_size=20)

        # 4) Stanley 파라미터 ─────────────────────────────────────
        self.k = rospy.get_param("~stanley_k", 1.0)
        self.v_eps = rospy.get_param("~vt_eps", 1.0)
        self.max_deg = rospy.get_param("~max_wheel_deg", 40.0)
        self.max_rad = self.max_deg * pi / 180.0
        self.invert_steer = rospy.get_param("~invert_steer", False)

        # 5) 속도 PI-D 파라미터 ──────────────────────────────────
        self.v_kp = rospy.get_param("~v_kp", 1.0 / 30.0)
        self.v_ki = rospy.get_param("~v_ki", 0.01)
        self.v_kd = rospy.get_param("~v_kd", 0.005)
        self.u_dead = rospy.get_param("~u_dead", 0.03)
        self.u_slew_rate = rospy.get_param("~u_slew_rate", 2.0)
        self.i_limit = rospy.get_param("~i_limit", 5.0)

        self.abs_kph_cap = rospy.get_param("~abs_kph_cap", 40.0)
        self.loop_hz = rospy.get_param("~loop_hz", 15.0)

        # 6) 정지/브레이크 홀드 파라미터 ──────────────────────────
        self.stop_window_m = rospy.get_param("~stop_window_m", 3.0)
        self.stop_radius_m = rospy.get_param("~stop_radius_m", 0.5)
        self.brake_hold_kph = rospy.get_param("~brake_hold_kph", 0.5)
        self.brake_hold_cmd = rospy.get_param("~brake_hold_cmd", 0.25)

        # 7) PI-D 내부 상태 변수 ──────────────────────────────────
        self.int_v = 0.0
        self.prev_kph = None
        self.prev_t = None
        self.last_u = 0.0
        self.last_sat = False

        # 8) MORAI 이벤트 서비스 설정 ─────────────────────────────
        self.event_cmd_enable = bool(rospy.get_param("~event_cmd_enable", True))
        self.event_srv_name = rospy.get_param("~event_srv_name", "/Service_MoraiEventCmd")
        self.set_gear_on_start = int(rospy.get_param("~set_gear_on_start", 4))      # 4:D
        self.set_ctrl_mode_on_start = int(rospy.get_param("~set_ctrl_mode_on_start", 3))  # 3:Auto
        self._event_connected = False
        self._event_done = False
        self._srv_event = None  # ServiceProxy

        # [ADD] LATTICE 입력 상태 ─────────────────────────────────
        self.lat_xs = None
        self.lat_ys = None
        self.lat_s  = None
        self.speed_flag = False
        self.last_lattice_stamp = rospy.Time(0)
        self.lattice_timeout = rospy.get_param("~lattice_timeout", 1.5)      # 최근 경로만 채택
        self.avoid_speed_cap_kph = rospy.get_param("~avoid_speed_cap_kph", 17.0)
        self._last_path_mode = "GLOBAL"

        rospy.Subscriber("/lattice_path", Path, self._lattice_cb, queue_size=1)  # [ADD]
        rospy.Subscriber("/speed_control", Bool, self._speed_flag_cb, queue_size=1)  # [ADD]

    # ───────────────────────────────────────────────────────────────────
    # /traffic 콜백 (값 저장만)
    def traffic_callback(self, msg):
        self.traffic_state = msg.data
        rospy.logdebug(f"[stanley] /traffic: {self.traffic_state}")

    # /stop_line 콜백 (값 저장만)
    def stop_line_callback(self, msg: Bool):
        self.stop_line_state = bool(msg.data)
        rospy.logdebug(f"[stanley] /stop_line: {self.stop_line_state}")

    # /global_waypoints 콜백 (최초 1회만 수락, 이후 무시)
    def _waypoints_callback(self, msg: waypointarray):
        if self.path_received:
            return

        if len(msg.waypoints) < 2:
            rospy.logerr("웨이포인트가 2개 미만이라 무시합니다.")
            return

        self.path = msg
        self.path_received = True

        # numpy 배열화
        self.xs = np.array([w.x for w in self.path.waypoints], dtype=float)
        self.ys = np.array([w.y for w in self.path.waypoints], dtype=float)
        self.vs = np.array([float(w.speed) for w in self.path.waypoints], dtype=float)

        ds = np.hypot(np.diff(self.xs), np.diff(self.ys))
        self.s = np.concatenate([[0.0], np.cumsum(ds)])     # 누적거리
        self.s_end = float(self.s[-1])
        self.last_xy = (self.xs[-1], self.ys[-1])            # 최종점 좌표
        self.N = len(self.xs)

        rospy.loginfo(f">> /global_waypoints 수신: {self.N} 개 (이후 수신은 무시)")

    # [ADD] lattice Path → arrays
    def _path_to_arrays(self, path: Path):
        xs = np.array([p.pose.position.x for p in path.poses], dtype=float)
        ys = np.array([p.pose.position.y for p in path.poses], dtype=float)
        ds = np.hypot(np.diff(xs), np.diff(ys))
        s  = np.concatenate([[0.0], np.cumsum(ds)])
        return xs, ys, s

    # [ADD] 최근 lattice 경로 저장
    def _lattice_cb(self, msg: Path):
        if not msg.poses:
            return
        self.lat_xs, self.lat_ys, self.lat_s = self._path_to_arrays(msg)
        self.last_lattice_stamp = rospy.Time.now()
        # 모드 전환 직후 역주행 인덱스 방지: 근처로 재시드
        if self.cur_pos is not None:
            d2 = (self.lat_xs - self.cur_pos.x)**2 + (self.lat_ys - self.cur_pos.y)**2
            self.j_idx = int(np.argmin(d2))

    # [ADD] 회피 활성 플래그
    def _speed_flag_cb(self, msg: Bool):
        self.speed_flag = bool(msg.data)

    # /status 콜백
    def status_callback(self, msg: status):
        self.cur_pos = msg.now_position.pose.position
        self.yaw = math.radians(msg.now_heading)
        self.kph = msg.now_speed
        self.status_received = True

    # ───────────────────────────────────────────────────────────────────
    # 속도 PI-D (원본)
    def speed_pid_step(self, tgt_kph: float, cur_kph: float, now: rospy.Time):
        if self.prev_t is None:
            dt = 1.0 / self.loop_hz
        else:
            dt = max((now - self.prev_t).to_sec(), 1e-3)

        e = tgt_kph - cur_kph
        d_meas = 0.0 if self.prev_kph is None else (cur_kph - self.prev_kph) / dt

        # P, I, D
        u_p = self.v_kp * e

        will_inc_sat = self.last_sat and ((self.last_u > 0 and e > 0) or (self.last_u < 0 and e < 0))
        if not will_inc_sat:
            self.int_v += e * dt
            self.int_v = float(np.clip(self.int_v, -self.i_limit, self.i_limit))
        u_i = self.v_ki * self.int_v
        u_d = -self.v_kd * d_meas

        u = u_p + u_i + u_d
        u_sat = float(np.clip(u, -1.0, 1.0))
        self.last_sat = (abs(u - u_sat) > 1e-6)

        # Slew-rate 제한
        max_du = self.u_slew_rate * dt
        u_cmd = float(np.clip(u_sat, self.last_u - max_du, self.last_u + max_du))

        # Dead-zone
        if abs(u_cmd) < self.u_dead:
            u_cmd = 0.0

        # 상태 저장
        self.prev_kph = cur_kph
        self.prev_t = now
        self.last_u = u_cmd

        # accel/brake 분리
        if u_cmd >= 0.0:
            accel, brake = u_cmd, 0.0
        else:
            accel, brake = 0.0, -u_cmd

        return accel, brake, u_cmd, e, d_meas, u_p, u_i, u_d

    # ───────────────────────────────────────────────────────────────────
    # MORAI 이벤트 서비스 (원본)
    def _connect_event_service(self):
        if not self.event_cmd_enable or self._event_connected:
            return
        try:
            rospy.wait_for_service(self.event_srv_name, timeout=1.0)
            self._srv_event = rospy.ServiceProxy(self.event_srv_name, MoraiEventCmdSrv)
            self._event_connected = True
            rospy.loginfo("[stanley] 이벤트 서비스 연결: %s", self.event_srv_name)
        except Exception as e:
            rospy.logwarn_throttle(2.0, "[stanley] 서비스 대기 중… (%s)", str(e))

    def _call_event(self, *, option=None, gear=None, ctrl_mode=None):
        if not (self.event_cmd_enable and self._event_connected and self._srv_event):
            return False
        try:
            req = MoraiEventCmdSrvRequest()
            req.request = EventInfo()
            if option is not None:
                req.request.option = int(option)
            if gear is not None:
                req.request.gear = int(gear)
            if ctrl_mode is not None:
                req.request.ctrl_mode = int(ctrl_mode)
            _ = self._srv_event(req)
            return True
        except Exception as e:
            rospy.logwarn_throttle(2.0, "[stanley] 이벤트 호출 실패: %s", str(e))
            return False

    def _ensure_event_mode(self):
        if not self.event_cmd_enable or self._event_done:
            return
        self._connect_event_service()
        if not self._event_connected:
            return
        ok1 = self._call_event(option=2, gear=self.set_gear_on_start)
        ok2 = self._call_event(option=1, ctrl_mode=self.set_ctrl_mode_on_start)
        if ok1 and ok2:
            self._event_done = True
            rospy.loginfo("[stanley] 기어 D, Automode 설정 완료")

    # ───────────────────────────────────────────────────────────────────
    # 메인 루프 (원본 + [ADD] lattice MUX)
    def run(self):
        rate = rospy.Rate(self.loop_hz)

        while not rospy.is_shutdown():
            self._ensure_event_mode()

            if not self.status_received:
                rospy.logwarn_throttle(5.0, "/status 수신 대기 …")
                rate.sleep()
                continue

            if not self.path_received:
                rospy.logwarn_throttle(5.0, "/global_waypoints 최초 수신 대기 … (구독 중)")
                rate.sleep()
                continue

            # [ADD] 활성 경로 선택 (lattice가 신선하고 speed_control True면 래티스 사용)
            now = rospy.Time.now()
            use_lat = (
                self.speed_flag and
                (self.lat_xs is not None) and (len(self.lat_xs) >= 2) and
                (now - self.last_lattice_stamp).to_sec() <= self.lattice_timeout
            )

            if use_lat:
                xs, ys, s = self.lat_xs, self.lat_ys, self.lat_s
                vcap = float(min(self.abs_kph_cap, self.avoid_speed_cap_kph))
                vs = np.full_like(xs, vcap, dtype=float)
                mode = "LATTICE"
            else:
                xs, ys, s, vs = self.xs, self.ys, self.s, self.vs
                mode = "GLOBAL"

            # [ADD] 모드 변경 시 인덱스 재시드(뒤로 뛰는 것 방지)
            if mode != getattr(self, "_last_path_mode", "GLOBAL"):
                d2 = (xs - self.cur_pos.x)**2 + (ys - self.cur_pos.y)**2
                self.j_idx = int(np.argmin(d2))
            self._last_path_mode = mode

            # 경로 관련 단축 참조 (원본)
            last_x, last_y = self.last_xy

            # 현재 위치/자세
            x, y, yaw = self.cur_pos.x, self.cur_pos.y, self.yaw
            c, sy = cos(yaw), sin(yaw)
            T_inv = np.array([[c, sy, -(c * x + sy * y)],
                              [-sy, c, (sy * x - c * y)],
                              [0.0, 0.0, 1.0]])

            # ★ 순차 전방점 탐색 ───────────────────────────────────
            N = len(xs)
            start = self.j_idx
            end = min(self.j_idx + self.search_ahead, N - 1)

            best_j = None
            best_d2 = float("inf")
            best_pl = None

            # (1) 창 내부 탐색
            for i in range(start, end + 1):
                pl = T_inv.dot([xs[i], ys[i], 1.0])
                if pl[0] <= 0.0:
                    continue
                d2 = pl[0] * pl[0] + pl[1] * pl[1]
                if d2 < best_d2:
                    best_j, best_d2, best_pl = i, d2, pl

            # (2) 창 안에 전방점 없으면 예외 검색 (뒤로는 보지 않음)
            if best_j is None:
                for i in range(self.j_idx, N):
                    pl = T_inv.dot([xs[i], ys[i], 1.0])
                    if pl[0] <= 0.0:
                        continue
                    d2 = pl[0] * pl[0] + pl[1] * pl[1]
                    if d2 < best_d2:
                        best_j, best_d2, best_pl = i, d2, pl

            # 인덱스 갱신 (뒤로 가지 않음)
            if best_j is not None and best_j >= self.j_idx:
                self.j_idx = best_j
            j = best_j
            plocal = best_pl
            # ──────────────────────────────────────────────────────

            # 남은 거리·종점 판정 (글로벌 기준 유지, 래티스 모드에서는 중도정지 방지)
            dist_to_last = sqrt((x - last_x) ** 2 + (y - last_y) ** 2)
            if mode == "GLOBAL" and j is not None:
                s_now = float(s[j])
                s_remain = max(0.0, self.s_end - s_now)
            else:
                s_remain = float("inf")

            at_terminal = (
                (s_remain <= self.stop_window_m) or
                (dist_to_last <= self.stop_radius_m) or
                (j is not None and j >= (self.N - 1) and mode == "GLOBAL")
            )

            # Stanley 조향 (원본)
            if j is not None:
                if j < N - 1:
                    path_yaw = atan2(ys[j + 1] - ys[j], xs[j + 1] - xs[j])
                else:
                    path_yaw = atan2(ys[j] - ys[j - 1], xs[j] - xs[j - 1])
                theta_e = wrap_angle(path_yaw - yaw)
                e_y = plocal[1]
                v_ms = max(self.kph / 3.6, 0.0)
                steer = theta_e + atan2(self.k * e_y, v_ms + self.v_eps)
                if self.invert_steer:
                    steer = -steer
                steer = float(np.clip(steer, -self.max_rad, self.max_rad))
            else:
                steer = 0.0

            # 목표 속도 (원본 로직: min(vs[j], abs_kph_cap) → vs는 모드별로 이미 선택됨)
            if at_terminal:
                tgt_kph = 0.0
            else:
                tgt_kph = 0.0 if j is None else float(min(vs[j], self.abs_kph_cap))

            # 속도 PI-D (원본)
            now = rospy.Time.now()
            accel, brake, u_cmd, e_kph, d_meas, u_p, u_i, u_d = \
                self.speed_pid_step(tgt_kph, self.kph, now)

            # 브레이크 홀드 (원본)
            if at_terminal and self.kph <= self.brake_hold_kph:
                accel = 0.0
                brake = max(brake, self.brake_hold_cmd)

            # 퍼블리시 (원본)
            self.cmd.steering = steer
            self.cmd.accel = accel
            self.cmd.brake = brake
            self.pub.publish(self.cmd)

            # 디버그 터미널 출력 (원본 유지)
            print("\033c", end="")
            print("──────── Stanley Seq + PI-D (sub→first only + lattice MUX) ────────")
            print(f" mode:{mode:7s} | idx: {j if j is not None else -1} / {self.N - 1}")
            print(f" yaw(deg):     {math.degrees(yaw):6.2f}")
            print(f" steer(deg):   {math.degrees(steer):6.2f} (±{self.max_deg}°)")
            print(f" cur/tgt kph:  {self.kph:5.2f} / {tgt_kph:5.2f}")
            print(f" s_remain(m):  {s_remain if s_remain<1e9 else -1:6.2f} | dist_last(m): {dist_to_last:6.2f}")
            print(f" at_terminal:  {at_terminal}")

            rate.sleep()


# ─────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    try:
        StanleyController().run()
    except rospy.ROSInterruptException:
        pass
