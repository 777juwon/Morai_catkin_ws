#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import numpy as np
from std_msgs.msg import Bool
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from custom_msgs.msg import waypoint, waypointarray

class PathMux:
    def __init__(self):
        rospy.init_node("path_mux", anonymous=True)

        # ===== 토픽 이름 =====
        # global_path_pub는 여기로만 퍼블리시 하도록 같이 바꿔줄 거야.
        self.topic_global_src = rospy.get_param("~global_src_topic", "/global_waypoints_src")
        self.topic_mux_out    = rospy.get_param("~mux_out_topic",    "/global_waypoints")
        self.lattice_kph      = rospy.get_param("~lattice_kph", 25.0)  # 라티스 구간 속도(kph)

        # 1) 전역 waypointarray (원본, SRC)
        self.global_wp_src = None
        rospy.Subscriber(self.topic_global_src, waypointarray, self.cb_global_src, queue_size=1)

        # 2) lattice Path
        self.lattice_path = None
        rospy.Subscriber("/lattice_path", Path, self.cb_lattice, queue_size=1)

        # 3) speed_control 플래그 (true=회피모드)
        self.use_lattice = False
        rospy.Subscriber("/speed_control", Bool, self.cb_flag, queue_size=1)

        # 4) 출력: Stanley가 구독하는 최종 경로
        self.pub = rospy.Publisher(self.topic_mux_out, waypointarray, queue_size=1)

        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            if self.use_lattice and self.lattice_path and self.global_wp_src:
                rospy.loginfo_throttle(1.0, "[PathMux] Using Lattice+GlobalTail")
                muxed = self.splice_lattice_with_global(self.lattice_path, self.global_wp_src, self.lattice_kph)
                self.pub.publish(muxed)
            elif self.global_wp_src:
                rospy.loginfo_throttle(2.0, "[PathMux] Using GlobalPath")
                self.pub.publish(self.global_wp_src)
            rate.sleep()

    def cb_global_src(self, msg):
        # 전역 웨이포인트 원본은 계속 갱신 받아 보관 (자기 메시지 재섭취 없음)
        self.global_wp_src = msg

    def cb_lattice(self, msg):
        self.lattice_path = msg

    def cb_flag(self, msg):
        self.use_lattice = bool(msg.data)

    # --------- 핵심: 라티스 + 전역 꼬리 붙이기 ----------
    def splice_lattice_with_global(self, lattice_path: Path, global_wp: waypointarray, lattice_kph: float):
        wa = waypointarray()

        # 1) 라티스 Path( map ) -> waypointarray (속도는 일정값)
        if lattice_path and lattice_path.poses:
            for ps in lattice_path.poses:
                w = waypoint()
                w.x = ps.pose.position.x
                w.y = ps.pose.position.y
                w.speed = lattice_kph
                wa.waypoints.append(w)

        # 2) 전역 웨이포인트 꼬리 찾기: 라티스 마지막 점과 가장 가까운 전역 인덱스부터 끝까지 붙임
        if global_wp and global_wp.waypoints:
            if wa.waypoints:
                lx = wa.waypoints[-1].x
                ly = wa.waypoints[-1].y
            else:
                # 라티스가 비었으면 그냥 전역만 리턴
                return global_wp

            xs = np.array([w.x for w in global_wp.waypoints], dtype=float)
            ys = np.array([w.y for w in global_wp.waypoints], dtype=float)
            d2 = (xs - lx)*(xs - lx) + (ys - ly)*(ys - ly)
            idx_tail = int(np.argmin(d2))

            # 3) 꼬리 붙이기 (전역 속도 그대로)
            for i in range(idx_tail, len(global_wp.waypoints)):
                wa.waypoints.append(global_wp.waypoints[i])

        return wa

if __name__=="__main__":
    try:
        PathMux()
    except rospy.ROSInterruptException:
        pass
