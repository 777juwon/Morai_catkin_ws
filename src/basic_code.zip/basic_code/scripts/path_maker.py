#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
from pathlib import Path
import rospy
from nav_msgs.msg import Odometry

class OdomToMando:
    def __init__(self):
        # 파라미터
        self.out_path = Path(rospy.get_param('~out', str(Path.home() / 'catkin_ws/path/mando_path.txt')))
        self.min_ds   = float(rospy.get_param('~min_ds', 1.0))   # 점 간 최소 거리(m)
        self.min_dt   = float(rospy.get_param('~min_dt', 0.0))   # 샘플 간 최소 시간(s), 0이면 미사용
        self.save_every = int(rospy.get_param('~save_every', 0)) # N>0이면 N개마다 중간 저장

        # 상태
        self.last_xy = None
        self.last_t  = None
        self.points  = []

        # 구독
        rospy.Subscriber('/odom', Odometry, self.cb, queue_size=100)
        rospy.on_shutdown(self.save_final)
        rospy.loginfo(f"[odom_to_mando] out={self.out_path}, min_ds={self.min_ds}, min_dt={self.min_dt}")

    def cb(self, msg: Odometry):
        p = msg.pose.pose.position
        now = msg.header.stamp if msg.header.stamp.to_sec() > 0 else rospy.Time.now()
        x, y, z = p.x, p.y, p.z

        if self.last_xy is None:
            self._append(x, y, z, now)
            return

        ds = math.hypot(x - self.last_xy[0], y - self.last_xy[1])
        dt = (now - self.last_t).to_sec() if self.last_t else 1e9

        if ds >= self.min_ds and dt >= self.min_dt:
            self._append(x, y, z, now)

    def _append(self, x, y, z, t):
        self.points.append((x, y, z))
        self.last_xy = (x, y)
        self.last_t  = t
        rospy.loginfo_throttle(1.0, f"[odom_to_mando] points={len(self.points)} (last: {x:.2f},{y:.2f},{z:.2f})")
        if self.save_every > 0 and len(self.points) % self.save_every == 0:
            self._save(intermediate=True)

    def _save(self, intermediate=False):
        self.out_path.parent.mkdir(parents=True, exist_ok=True)
        with self.out_path.open('w') as f:
            f.write("# x y z\n")
            for x, y, z in self.points:
                f.write(f"{x:.6f} {y:.6f} {z:.6f}\n")
        if intermediate:
            rospy.loginfo(f"[odom_to_mando] intermediate save: {len(self.points)} pts -> {self.out_path}")

    def save_final(self):
        self._save(intermediate=False)
        rospy.loginfo(f"[odom_to_mando] FINAL save: {len(self.points)} pts -> {self.out_path}")

if __name__ == '__main__':
    rospy.init_node('odom_to_mando', anonymous=False)
    OdomToMando()
    rospy.spin()